<?php

use Bitrix\Main\Config\Option;
use Bitrix\Main\Context;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Text\HtmlFilter;
use Bitrix\Main\Type\DateTime;
use Bitrix\Currency;

$module_id = 'paymentacceptance';

IncludeModuleLangFile($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/options.php");

$arAllOptions = Array(
    array("BIT_KKT_TOKEN", "токен кассового аппарата.", 
	array("text"), ""),

    array("BIT_BNK_TRM_TOKEN", "токен банковского терминала.", 
	array("text"), "" ),

    array("BIT_PROG_URL", "BIT_PROG_URL" , 
	array("text"),  "http://localhost:44735" ) 
);


$RIGHT = $APPLICATION->GetGroupRight($module_id);

if ($RIGHT >= 'R')
{
	Loader::includeModule('paymentacceptance');

	$settingsUrl = $APPLICATION->GetCurPage() . '?lang=' . LANGUAGE_ID . '&mid=' . $module_id;

	$request = Context::getCurrent()->getRequest();

	$aTabs = [
		[
			'DIV' => 'edit0',
			'TAB' => Loc::getMessage('PA_SETTINGS'),
			'ICON' => 'paymentacceptance_settings',
			'TITLE' => Loc::getMessage('PA_SETTINGS_TITLE'),
		],
		[
			'DIV' => 'edit1',
			'TAB' => Loc::getMessage('CO_TAB_RIGHTS'),
			'ICON' => 'paymentacceptance_settings',
			'TITLE' => Loc::getMessage('CO_TAB_RIGHTS_TITLE'),
		],
	];
	
	$tabControl = new CAdminTabControl('TabControl', $aTabs, true, true);
	CModule::IncludeModule($module_id);

	if($REQUEST_METHOD=="POST" && strlen($Update.$Apply.$RestoreDefaults) > 0 && $RIGHT=="W" && check_bitrix_sessid())
	{
		require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/perfmon/prolog.php");

		if(strlen($RestoreDefaults)>0)
			COption::RemoveOption("WE_ARE_CLOSED_TEXT");
		else
		{
			foreach($arAllOptions as $arOption)
			{
				$name=$arOption[0];
				$val=$_REQUEST[$name];
				// @todo: проверка безопасности должна быть тут!
				COption::SetOptionString($module_id, $name, $val);
			}
		}

		ob_start();
		$Update = $Update.$Apply;
		//require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/group_rights.php");
		ob_end_clean();
	}


	$tabControl->Begin();
	?>
	
	<form method="POST" action="<?= $APPLICATION->GetCurPage(); ?>?lang=<?= LANGUAGE_ID; ?>&mid=<?= $module_id; ?>" >
	<?= bitrix_sessid_post();

	$tabControl->BeginNextTab();

	
    foreach($arAllOptions as $arOption)
	{
	
        $val = COption::GetOptionString($module_id, $arOption[0], $arOption[3]);
		
        $type = $arOption[2];

		$lbl = htmlspecialcharsbx($arOption[0]);
        $opt1 = htmlspecialcharsbx($arOption[1]);
		echo '
        <tr>
            <td width="40%" nowrap '.(($type[0]=="textarea")?'class="adm-detail-valign-top"':'').'
			
                <label for="'.$lbl.'">
					'.$opt1.':
				</label>';
				?>
            <td width="60%">
			
                <?if($type[0]=="checkbox"):?>
                    <input type="checkbox" name="<?echo htmlspecialcharsbx($arOption[0])?>" id="<?echo htmlspecialcharsbx($arOption[0])?>" value="Y"<?if($val=="Y")echo" checked";?>>
					
                <?elseif($type[0]=="text"):?>
                    <input type="text" size="<?echo $type[1]?>" maxlength="255" value="<?echo htmlspecialcharsbx($val)?>" name="<?echo htmlspecialcharsbx($arOption[0])?>" id="<?echo htmlspecialcharsbx($arOption[0])?>"><?if($arOption[0] == "slow_sql_time") echo GetMessage("PERFMON_OPTIONS_SLOW_SQL_TIME_SEC")?>
					
                <?elseif($type[0]=="textarea"):?>
                    <textarea rows="<?echo $type[1]?>" cols="<?echo $type[2]?>" name="<?echo htmlspecialcharsbx($arOption[0])?>" id="<?echo htmlspecialcharsbx($arOption[0])?>"><?echo htmlspecialcharsbx($val)?></textarea>
                <?endif?>
            </td>
        </tr>
    <?
	}
	?>


	<?php
	$tabControl->BeginNextTab();

	require_once $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/admin/group_rights.php';

	$tabControl->Buttons();?>
	
<script>

function RestoreDefaults()
{
	if (confirm('<?= CUtil::JSEscape(Loc::getMessage("CUR_OPTIONS_BTN_HINT_RESTORE_DEFAULT_WARNING")); ?>'))
	{
		window.location = "<?= $APPLICATION->GetCurPage(); ?>?lang=<?= LANGUAGE_ID; ?>&mid=<?= $module_id; ?>&RestoreDefaults=Y&<?= bitrix_sessid_get()?>";
	}
}
</script>

	<input
		type="submit"<?= ($RIGHT < 'W' ? ' disabled' : ''); ?>
		name="Update"
		class="adm-btn-save"
		value="<?= HtmlFilter::encode(Loc::getMessage('CUR_OPTIONS_BTN_SAVE')); ?>"
		title="<?= HtmlFilter::encode(Loc::getMessage('CUR_OPTIONS_BTN_SAVE_TITLE')); ?>"
	>
	<input
		type="reset"
		name="reset"
		value="<?= HtmlFilter::encode(Loc::getMessage('CUR_OPTIONS_BTN_RESET')); ?>"
		title="<?= HtmlFilter::encode(Loc::getMessage('CUR_OPTIONS_BTN_RESET_TITLE')); ?>"
	>
	<input
		type="button"<?= ($RIGHT < 'W' ? ' disabled' : ''); ?>
		value="<?= HtmlFilter::encode(Loc::getMessage('CUR_OPTIONS_BTN_RESTORE_DEFAULT')); ?>"
		title="<?= HtmlFilter::encode(Loc::getMessage('CUR_OPTIONS_BTN_HINT_RESTORE_DEFAULT')); ?>"
		onclick="RestoreDefaults();"
	>

    <?$tabControl->End();?>
	
	</form>
	


<?php
	
}
?>