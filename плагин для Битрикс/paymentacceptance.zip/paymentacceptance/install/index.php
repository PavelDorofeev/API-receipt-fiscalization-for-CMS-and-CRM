<?php

use Bitrix\Main;
use Bitrix\Main\Loader;
use Bitrix\Main\ModuleManager;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Localization\LanguageTable;
use Bitrix\Main\SiteTable;

Loc::loadMessages(__FILE__);

class paymentacceptance extends CModule
{
	var $MODULE_ID = 'paymentacceptance';
	var $MODULE_VERSION;
	var $MODULE_VERSION_DATE;
	var $MODULE_NAME;
	var $MODULE_DESCRIPTION;
	var $MODULE_CSS;
	var $MODULE_GROUP_RIGHTS = 'Y';
	var $errors = false;

	function __construct()
	{
		$arModuleVersion = array();

		include(__DIR__.'/version.php');

		if (!empty($arModuleVersion['VERSION']))
		{
			$this->MODULE_VERSION = $arModuleVersion["VERSION"];
			$this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];
		}

		$this->MODULE_NAME = Loc::getMessage("PA_INSTALL_NAME");
		$this->MODULE_DESCRIPTION = Loc::getMessage("PA_INSTALL_DESCRIPTION");
	}

	function DoInstall()
	{
		global $APPLICATION;
		
		$this->InstallFiles();
		$this->InstallDB();
		$this->InstallEvents();
		$GLOBALS["errors"] = $this->errors;

	}

	function DoUninstall()
	{
		global $APPLICATION, $step;
		$step = (int)$step;
		
		$this->UnInstallDB();
		$this->UnInstallEvents();		
	}

	function InstallDB()
	{
		global $DB, $APPLICATION;

		ModuleManager::registerModule('paymentacceptance');

		return true;
	}

	function UnInstallDB()
	{
		global $DB, $APPLICATION;

		$connection = Main\Application::getConnection();

		$this->errors = false;

		CAgent::RemoveModuleAgents('paymentacceptance');
		ModuleManager::unRegisterModule('paymentacceptance');

		return true;
	}

	function InstallEvents()
	{
		$eventManager = \Bitrix\Main\EventManager::getInstance(); 
		
		$eventManager->registerEventHandler(  "main", "OnAdminSaleOrderViewDraggable",
           $this->MODULE_ID,
           "PaymentAcceptanceClass", "onInit");
		   
		return true;
	}

	function UnInstallEvents()
	{
		$eventManager = \Bitrix\Main\EventManager::getInstance(); 
		
		$eventManager->unRegisterEventHandler(   "main", "OnAdminSaleOrderViewDraggable",
           $this->MODULE_ID,
           "PaymentAcceptanceClass", "onInit");
		
		return true;
	}

	function InstallFiles()
	{
		//CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/local/modules/paymentacceptance/install/components", $_SERVER["DOCUMENT_ROOT"]."/bitrix/components", true, true);
		
		return true;
	}

	function UnInstallFiles()
	{

		return true;
	}

}
