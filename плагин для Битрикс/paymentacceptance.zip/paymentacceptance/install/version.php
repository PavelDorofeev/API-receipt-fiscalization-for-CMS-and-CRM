<?php
$arModuleVersion = [
	'VERSION' => '1.0.0',
	'VERSION_DATE' => '2024-09-11 11:20:00',
];
