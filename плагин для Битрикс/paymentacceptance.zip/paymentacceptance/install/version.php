<?php
$arModuleVersion = [
	'VERSION' => '1.2.0',
	'VERSION_DATE' => '2024-09-23 19:23:00',
];
