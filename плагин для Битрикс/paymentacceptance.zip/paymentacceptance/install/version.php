<?php
$arModuleVersion = [
	'VERSION' => '1.1.0',
	'VERSION_DATE' => '2024-09-19 17:23:00',
];
