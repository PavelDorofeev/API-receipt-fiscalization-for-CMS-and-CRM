<?
$MESS["PA_CONTROL"] = "Оплаты при самовывозе";
$MESS["PAYMENTS"] = "Виды оплат";
$MESS["PA_ALT"] = "Управление оплатами при самовывозе";
$MESS["paymentacceptance_menu_title"] = "оплаты при самовывозе";
?>