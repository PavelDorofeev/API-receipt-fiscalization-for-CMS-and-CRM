<?
$MESS["PA_CONTROL"] = "payments (on pickup)";
$MESS["PAYMENTS"] = "payment acceptance";
$MESS["PA_ALT"] = "payments managment";
$MESS["paymentacceptance_menu_title"] = "payments with pickup";
?>