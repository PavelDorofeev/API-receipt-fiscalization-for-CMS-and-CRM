<?
$MESS["PA_INSTALL_NAME"] = "Payment Acceptance";
$MESS["PA_INSTALL_DESCRIPTION"] = "Cash or bank card.";
$MESS["PA_INSTALL_TITLE"] = "Currencies module installation";

$MESS["PA_INSTALL_COMPLETE_ERROR"] = "Installation completed with errors";
$MESS["PA_INSTALL_ERROR"] = "Installation errors";
$MESS["PA_INSTALL_BACK"] = "Back to module management section";
$MESS["PA_UNINSTALL_WARNING"] = "Warning! The module will be uninstalled from the system.";
$MESS["PA_UNINSTALL_SAVEDATA"] = "To save the data stored in the database tables, check the &quot;Save tables&quot; checkbox.";
$MESS["PA_UNINSTALL_SAVETABLE"] = "Save tables";
$MESS["PA_UNINSTALL_DEL"] = "Uninstall";
$MESS["PA_UNINSTALL_ERROR"] = "Uninstall errors:";
$MESS["PA_UNINSTALL_COMPLETE"] = "Uninstall complete.";
$MESS["PA_INSTALL_PUBLIC_SETUP"] = "Install";
$MESS["PA_INSTALL_UNPOSSIBLE"] = "The module cannot be uninstalled.";
$MESS["PA_BASE_EMPTY"] = "No base paymentacceptance specified. The module cannot function as designed. Please specify the base paymentacceptance on the <a href=\"#LINK#\">module settings page</a>.";
$MESS["PA_BASE_ERROR"] = "No base paymentacceptance specified; the exchange rate of some of the currencies is 1. The module cannot function as designed. Please specify the base paymentacceptance on the <a href=\"#LINK#\">module settings page</a>.";
?>