<?php
const ADMIN_MODULE_NAME = 'paymentacceptance';
