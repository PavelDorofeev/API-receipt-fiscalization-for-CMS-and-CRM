<?php

use Bitrix\Main\Loader;
/*
Loader::registerAutoLoadClasses(
	'paymentacceptance',
	[
	]
);
*/
use Bitrix\Main;
use Bitrix\Main\ModuleManager;
use Bitrix\Main\Localization\Loc;

Loc::loadMessages(__FILE__);

$ff = CJSCore::Init(array("jquery"));

$loaded = Bitrix\Main\Page\Asset::getInstance()->addJs('/local/modules/paymentacceptance/js/jquery-ui.js');
$loaded = Bitrix\Main\Page\Asset::getInstance()->addJs('/local/modules/paymentacceptance/js/bit_drv_kkt.js');

$APPLICATION->SetAdditionalCSS("/local/modules/paymentacceptance/css/bit_drv_kkt.css");
/*
$cmp = $APPLICATION->IncludeComponent(
	"bitrix:paymentacceptance.something",         // имя компонента main.include
	"",     //его шаблон, пустая строка если шаблон по умолчанию
	$arParams=array(),      // параметры
	$parentComponent=null,  // null или объект родительского компонента
	$arFunctionParams=array()
 );

if (! $cmp )
{

}*/

\Bitrix\Main\EventManager::getInstance()->addEventHandler("main", "OnAdminSaleOrderViewDraggable", array("PaymentAcceptance123", "onInit"));


class PaymentAcceptance123
{
	public static function onInit()
	{

		return array("BLOCKSET" => "PaymentAcceptance123",
			"getScripts"  => array("PaymentAcceptance123", "mygetScripts"),
			"getBlocksBrief" => array("PaymentAcceptance123", "mygetBlocksBrief"),
			"getBlockContent" => array("PaymentAcceptance123", "mygetBlockContent"),
			);
	}
		
	public static function mygetBlocksBrief($args)
		{
			$id = !empty($args['ORDER']) ? $args['ORDER']->getId() : 0;

			return array(
				'payments_pickup' => array("TITLE" => "Оплата заказа при самовывозе")
			);
		}
	
	public static function mygetScripts($args)
	{
		$BIT_KKT_TOKEN = COption::GetOptionString('paymentacceptance', 'BIT_KKT_TOKEN');
		if( $BIT_KKT_TOKEN != "")
			$BIT_KKT_TOKEN = "\nvar BIT_KKT_TOKEN='$BIT_KKT_TOKEN';";

		$BIT_BNK_TRM_TOKEN = COption::GetOptionString('paymentacceptance', 'BIT_BNK_TRM_TOKEN');
		if( $BIT_BNK_TRM_TOKEN != "")
			$BIT_BNK_TRM_TOKEN = "\nvar BIT_BNK_TRM_TOKEN='$BIT_BNK_TRM_TOKEN';";

		$BIT_PROG_URL = COption::GetOptionString('paymentacceptance', 'BIT_PROG_URL');
		if( $BIT_PROG_URL != "")
			$BIT_PROG_URL = "\nvar BIT_PROG_URL='$BIT_PROG_URL';";

		$ORDER = $args["ORDER"];

		$orderID = $ORDER->getId();
		if($orderID>0)
			$orderID = "\nvar orderID=$orderID;";
						
		return '<script type="text/javascript">'.$BIT_KKT_TOKEN.$BIT_BNK_TRM_TOKEN.$BIT_PROG_URL.$orderID.'</script>';
	}
		
	public static function mygetBlockContent($blockCode, $selectedTab, $args)
	{
		$result = '';
		$id = !empty($args['ORDER']) ? $args['ORDER']->getId() : 0;
		
		if ($selectedTab == 'tab_order')
		{
			$mdl = Loader::includeModule('paymentacceptance');
			
			if ( ! $mdl )
			{

			}

			if ($blockCode == 'payments_pickup')
			{
				$jsn = [];

				$ORDER=$args['ORDER'];

				$sum= $ORDER->getPrice();
				$isPaid = $ORDER->isPaid();
				$basket = $ORDER->getBasket();

				//$basket = $ORDER->getBasketItems();

				$id = \Bitrix\Main\Engine\CurrentUser::get()->getId();
				$bb = \Bitrix\Main\Engine\CurrentUser::get()->isAdmin();
				$login = \Bitrix\Main\Engine\CurrentUser::get()->getLogin();
				$fio = \Bitrix\Main\Engine\CurrentUser::get()->getFullName();
				
				$purchases=[];
				foreach( $basket as $kk => $itm)
				{
					$item=[];
					$item["productName_1030"]= $itm->getField('NAME');
					$item["price_1079"]= $itm->getPrice();
					$item["qty_1023"]= $itm->getQuantity();
					//$item["getWeight"]= $itm->getWeight();
					$item["getVatRate"] = $itm->getVatRate();
					$item["unit_2108"]=0;
					$item["paymentFormCode_1214"]=2;
					$item["productTypeCode_1212"]=3;
					$item["tax_1199"]= 6;
					//$item["additionalAttribut_1191"] = "что-то дополнительное";
					
					$purchases[] = $item;
				}
				$jsn ["purchases"] = $purchases;


				$jsn ["cashierInn_1203"] = $fio;
				$jsn ["taxationType_1055"] = 5;
				$jsn ["receiptType_1054"] = 1;
				//$jsn ["sendToEmail_1008"] = "";
				$jsn ["electronically"] = false;

				$json_data = json_encode($jsn ,JSON_PRETTY_PRINT| JSON_UNESCAPED_UNICODE);
				$result = 'Заказ № '.$id.'<BR>Сумма к оплате: <span id="k_oplate">'.$sum.'</span>&nbsp;<div id="paymentBtns"><button id="btnCash">Наличными</button> <button id="btnECash">Банковской картой</button></div><br><textarea id="json_data" style="width:100%">'.$json_data.'</textarea>';
			}
		}
		$aaaa= 123;
		return $result;
	}
}

