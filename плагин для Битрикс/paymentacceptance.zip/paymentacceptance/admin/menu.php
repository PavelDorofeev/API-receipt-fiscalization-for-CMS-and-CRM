<?
/** @global CMain$APPLICATION */
use Bitrix\Main\Localization\Loc;

Loc::loadMessages(__FILE__);

if ($APPLICATION->GetGroupRight('paymentacceptance') == 'D')
	return false;

return array(
	"parent_menu" => "global_menu_settings",
	"section" => "paymentacceptance",
	"sort" => 300,
	"text" => Loc::getMessage("PA_CONTROL"),
	"title" => Loc::getMessage("paymentacceptance_menu_title"),
	"icon" => "paymentacceptance_menu_icon",
	"page_icon" => "paymentacceptance_page_icon",
	"items_id" => "menu_paymentacceptance",
	"items" => array(
		array(
			"text" => Loc::getMessage("PAYMENTS"),
			"title" => Loc::getMessage("PA_ALT"),
			"url" => "paymentacceptance.php?lang=".LANGUAGE_ID,
			"more_url" => array(
			)
		)
	)
);