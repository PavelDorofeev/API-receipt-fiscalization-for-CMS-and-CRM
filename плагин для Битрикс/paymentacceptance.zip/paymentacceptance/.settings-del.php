<?php
return [
	/*'controllers' => [
		'value' => [
			'defaultNamespace' => '\\Bitrix\\Currency\\Controller',
		],
		'readonly' => true,
	],*/
];
