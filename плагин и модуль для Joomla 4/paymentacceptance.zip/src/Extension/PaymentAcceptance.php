<?php

/**

 */

namespace Joomla\Plugin\System\PaymentAcceptance\Extension;

use Joomla\CMS\Cache\Cache;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Helper;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Component\Paymentsacceptance\Administrator\Helper\PaymentsacceptanceHelper;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\Exception\ExecutionFailureException;
use Joomla\Database\ParameterType;
use Joomla\Event\DispatcherInterface;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * Joomla! Users Actions Logging Plugin.
 *
 * @since  3.9.0
 */
use Joomla\Event\SubscriberInterface; // добавили

final class PaymentAcceptance extends CMSPlugin  implements SubscriberInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;

    private $order;
    private $order_items;

    public function __construct(DispatcherInterface $dispatcher, array $config)
    {
        parent::__construct($dispatcher, $config);

        // Import actionlog plugin group so that these plugins will be triggered for events
		
		// ЭТО ВНИМАНИЕ ГРУППА !!!
        
		////PluginHelper::importPlugin('paymentacceptance');
		
		$BIT_KKT_TOKEN = $this->params->get( 'BIT_KKT_TOKEN', '' );
        $BIT_BNK_TRM_TOKEN = $this->params->get( 'BIT_BNK_TRM_TOKEN', '' );
    }

    public static function getSubscribedEvents(): array
     {
         return [
             'onBeforeShowOrder' => 'onBeforeShowOrder',
             'onBeforeDisplayOrderAdmin' => 'onBeforeDisplayOrderAdmin',
             'onBeforeEditOrders' => 'onBeforeEditOrders',
             'onBeforeDisplayAddons' => 'onBeforeDisplayAddons',
             'onBeforeDisplayListOrderAdmin' => 'onBeforeDisplayListOrderAdmin'
             
              
         ];
     }

     public function onBeforeDisplayListOrderAdmin( &$view )
     {
        $order = $view;
     }
     public function onBeforeDisplayAddons( &$view )
     {
        $order = $view;
     }

     public function onBeforeDisplayOrderAdmin( &$arr )
     {
        $this->order = $arr[0];
        $this->order_items = $arr[1];
     }
     public function getOrder()
     {
        return $this->order;    
     }
     public function getOrderItems()
     {
        return $this->order_items;    
     }
     public function onBeforeEditOrders( &$view )
     {
        $order = $view;
     }
     public function onBeforeShowOrder( &$arr )
     {
        $view = $arr[0]; // HtmlView
        $ord = $view->order;
        $dd= $ord->getCurrentOrderStatus();
        $order_id = $ord->order_id;
        $itms = $ord->items;

        $ord->Number =123;

        foreach( $itms as $kk=>$itm)
        {
            $product_name = $itm->product_name;
            $product_quantity = $itm->product_quantity;
            //addLog($product_name,'','');
        }

        //ToolbarHelper::custom('send', 'mail', 'mail', '3453454', false);
        //FormHelper::
        //HTMLHelper::
        //LayoutHelper::

        //$document = JFactory::getDocument();
        jimport('joomla.application.module.helper');
        $ll = ModuleHelper::getModuleList();
        foreach($ll as $kk=>$vv)
        {

        }
        //$lo = ModuleHelper::getLayoutPath('mod_vk_contactus', $params->get('layout', 'default'));
        //$mods = ModuleHelper::getModule('mod_vk_contactus');
        //echo ModuleHelper::renderModule($mods);


     }



}
