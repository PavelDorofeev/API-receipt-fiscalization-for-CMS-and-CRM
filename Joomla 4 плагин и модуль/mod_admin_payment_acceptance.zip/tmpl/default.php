<?php defined('_JEXEC') or die;

// Объявляем переменную, и записываем в неё данные из настроек модуля, а именно поле ID группы
$group_id = $params['group_id'];

?>
<?php // скрипт ниже, можно было бы подключить в mod_vk_contactus.php и вывести в head, но я решил оставить его тут ?>
<script type="text/javascript" src="https://vk.com/js/api/openapi.js?160"></script>

<!-- VK Widget -->
<div><?php echo "заказ : ".$order->order_id;?>
    <span>Оплата:</span>
    <span id="k_oplate"><?php echo $k_oplate;?></span>
    <button class="button btn btn-primary" id="btnCash">Наличными</button>
    <button class="button btn btn-primary" id="btnECash">Картой</button>
</div>

<div>
    <textarea id="json_data" style="width:100%;height:100%;"><?php echo json_encode( $json_data , JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE ); ?></textarea>
</div>

<div id="vk_contact_us"></div>
<script type="text/javascript">
//VK.Widgets.ContactUs("vk_contact_us", {}, -<?php echo $group_id; // вывели id группы ?>);
</script>