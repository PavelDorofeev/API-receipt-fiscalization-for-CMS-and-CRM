<?php defined('_JEXEC') or die;

//namespace Joomla\Module\StatsAdmin\Administrator\Helper;

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Object\CMSObject;
use Joomla\Event\Dispatcher;
use Joomla\CMS\Factory;
use \Joomla\CMS\HTML\HTMLHelper as JHtml;

$document = JFactory::getDocument();
//??$uri    = JFactory::getURI();

$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
//$wa->useScript('keepalive');

//$wa->registerAndUseScript('shared', 'shared.js', [], [], []);
$root  = JURI::root();
//$rr1 = JURI::site();
$path = JPATH_COMPONENT;
$path2 = $_SERVER['DOCUMENT_ROOT'];
$document = JFactory::getDocument();

$document->addScript('../media/mod_admin_payment_acceptance/js/bit_drv_kkt.js');
$document->addScript('../media/mod_admin_payment_acceptance/js/jquery-ui.js');

$document->addStyleSheet('../media/mod_admin_payment_acceptance/css/bit_drv_kkt.css');

//$document->addScriptDeclaration( 'jQuery(document).ready(function() { var myVar = ' . $this->params->get( 'nfa', 0 ). ';});.' );
//$this->params->get( 'nfa', 0 )

//$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
//$wa->useScript('jquery');
//JHtml::_('jquery.framework');
//JHtml::_('jquery.ui');



if( ! array_key_exists( "controller" , $_GET ) ||  $_GET["controller"] != "orders" )
	;
if( ! array_key_exists( "task" , $_GET ) ||  $_GET["task"] != "show" )
	;
if( ! array_key_exists( "order_id" , $_GET )  )
	;
else
{	
	$pluginEnable = PluginHelper::isEnabled('system' , 'paymentacceptance');

	if( $pluginEnable )
	{
		$myPlugin = Factory::getApplication()->bootPlugin('paymentacceptance','system');

		$BIT_PROG_URL = $myPlugin->params->get( 'BIT_PROG_URL', '' );
		$BIT_KKT_TOKEN = $myPlugin->params->get( 'BIT_KKT_TOKEN', '' );
		$BIT_BNK_TRM_TOKEN = $myPlugin->params->get( 'BIT_BNK_TRM_TOKEN', '' );
		
		$order = $myPlugin->getOrder();

		$document->addScriptDeclaration( 'var BIT_KKT_TOKEN = "' . $myPlugin->params->get( 'BIT_KKT_TOKEN', '' ). '";
		var BIT_BNK_TRM_TOKEN = "' . $myPlugin->params->get( 'BIT_BNK_TRM_TOKEN', '' ). '";
		var BIT_PROG_URL = "' . $myPlugin->params->get( 'BIT_PROG_URL', '' ). '";	
		var orderID = "' . $order->order_id.'";' );

		$order_items = $myPlugin->getOrderItems();

		$k_oplate = $order->order_subtotal;

		set_json_data( $order, $order_items, $json_data);

	}

	require ModuleHelper::getLayoutPath('mod_admin_payment_acceptance', $params->get('layout', 'default'));
}

function set_json_data( &$order, &$order_items, &$json_data)
{
	if( ! is_object($order) )
		return "ошибка: данные заказа не распознаны";

	if( ! is_array($order_items) )
		return "ошибка: состав заказа не распознан";		

	$items=[];

	foreach ($order_items as $item => $arr)
	{
		$itm=[];

		$itm["productName_1030"] = $arr->product_name;
		$itm["price_1079"] = $arr->product_item_price;
		$itm["qty_1023"] = $arr->product_quantity;
		//$itm["sum"] = $arr->get_subtotal();
		$itm["unit_2108"] = 0;
		$itm["paymentFormCode_1214"] = 4;
		$itm["tax_1199"] = 6;

		$items[] = $itm;
	}

	$data["purchases"] = $items; 
	$data["cashierName_1021"] = "Пупкин Иван Трофимович";
	$data["cashierInn_1203"]= "";
	$data["taxationType_1055"]= 5;
	$data["receiptType_1054"]= 1;
	//$data["sendToEmail_1008"]= 1;

	$json_data = $data;
}

?>