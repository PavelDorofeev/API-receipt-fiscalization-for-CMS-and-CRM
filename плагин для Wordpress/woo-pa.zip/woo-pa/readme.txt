=== WooCommerce Payment Acceptance ===

Contributors: BIT Ltd
Tags: backend, manual, phone, payment, woocommerce
Requires at least: 4.7
Tested up to: 6.6
Requires PHP: 5.6
Stable tag: 2.8.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Process payments from the WooCommerce Edit Order screen.

== Description ==

### Features


== Installation ==

Scroll down for configuration instructions.

### Requirements

* WordPress 4.7+
* WooCommerce 3.3+
* PHP 5.6+


### Installation



### Configuration

== Screenshots ==

== Changelog ==

= 1.0.0 =

First release