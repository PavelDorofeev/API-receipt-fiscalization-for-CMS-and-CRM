<?php defined( 'ABSPATH' ) || die; ?>

<div class="upgrade-container">
    <p class="upgrade-text">Refund is a Pro feature</p>
    <a href="<?= esc_url( WOO_PA_UPGRADE_URL ) ?>" target="_blank" class="button button-primary button-hero upgrade-button">Upgrade Now</a>
</div>

<div class="action-button-bar">
    <div class="action-buttons">
        <button type="button" class="button right" data-close-panel>Close</button>
    </div>
</div>
