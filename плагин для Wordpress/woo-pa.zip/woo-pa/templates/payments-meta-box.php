<?php defined( 'ABSPATH' ) || die; ?>

<div id="woo-pa-main">

    <div class="global-notice" hidden></div>
	
    <?php $this->template( 'notice-template' ); ?>

    <?php $this->template( 'notice-sections-template' ); ?>

    <div>

        <div class="action-button-bar">
            <div class="action-buttons">
            <label>ОПЛАТИТЬ : <input id="k_oplate" type="number" size="8" type="number" readonly value="<?php echo "".$this->get_k_oplate()."";?>" /></label>
                <button id="btnCash" type="button" class="button button-primary" >Наличными</button>
                <button id="btnECash" type="button" class="button button-primary" >По карте</button>
            </div>
        </div>
		<textarea id="json_data" style="width:100%;height:100%;"><?php echo json_encode( $this->get_json_data() , JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE ); ?></textarea>
    </div>
 

</div>
