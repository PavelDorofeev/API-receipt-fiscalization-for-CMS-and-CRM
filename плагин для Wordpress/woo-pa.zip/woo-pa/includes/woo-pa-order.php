<?php

namespace Woo_PA;

use WC_Order;

defined( 'ABSPATH' ) || die;

/**
 * Transparently adds plugin-specific functionality to a WooCommerce order
 * object (most often an instance of 'WC_Order').
 *
 * Use it like a regular WooCommerce order object.
 */
class Woo_PA_Order {

    /**
     * The core order object.
     *
     * @var WC_Order|object
     */
    private $order;

    /**
     * Set the core order object.
     *
     * @param WC_Order|object $order The order.
     */
    public function __construct( $order ) {
        $this->order = $order;
    }

    /**
     * Call a method on the core order object.
     *
     * @param  string $name      The method name.
     * @param  array  $arguments The arguments to pass to the method.
     * @return mixed             The return value of the method.
     */
    public function __call( $name, $arguments ) {
        return $this->order->$name( ...$arguments );
    }

    /**
     * Get the core order object.
     *
     * @return WC_Order|object The order.
     */
    public function get_core_order() {
        return $this->order;
    }

    /**
     * Get a list of charge properties and their default values.
     *
     * This is for normalizing charge records across versions.
     *
     * @return array The properties and their defaults.
     */
    private function get_charge_defaults() {
        return [
            'id'              => '',
            'date'            => current_time( 'M d, Y' ),
            'last4'           => '',
            'amount'          => 0,
            'currency'        => '',
            'captured'        => false,
            'held_for_review' => false,
        ];
    }


    public function get_woo_pa_payments() 
		{
        $payments = json_decode(
            $this->get_meta( 'woo-pa-' . WOO_PA_PAYMENT_PROCESSOR . '-charges', true ),
            true
        ) ?: [];

        $charge_defaults = $this->get_charge_defaults();

        foreach ( $payments as $key => $payment ) {
            $payments[ $key ] += $charge_defaults;
        }

        return $payments;
    }

    public function add_woo_pa_payment( $payment ) 
	{
        $payment += $this->get_charge_defaults();

        $payments = $this->get_woo_pa_payments();

        $payments[] = $payment;

        $this->update_meta_data( 'woo-pa-' . WOO_PA_PAYMENT_PROCESSOR . '-charges', json_encode( $payments ) );
    }


    public function get_total_amount_paid( $currency = 'order_currency' ) 
	{
        $payments = $this->get_woo_pa_payments();

        if ( $currency !== 'all_currencies' ) {
            $currency = $currency === 'order_currency' ? $this->get_currency() : $currency;

            $payments = wp_list_filter( $payments, [ 'currency' => $currency ] );
        }

        return round( array_sum( array_column( $payments, 'amount' ) ), 2 );
    }


    public function get_total_amount_unpaid() {
        return round( $this->get_total() - $this->get_total_amount_paid(), 2 );
    }


    public function is_multicurrency() {
        return count( array_unique( array_column( $this->get_woo_pa_payments(), 'currency' ) ) ) > 1;
    }

}
