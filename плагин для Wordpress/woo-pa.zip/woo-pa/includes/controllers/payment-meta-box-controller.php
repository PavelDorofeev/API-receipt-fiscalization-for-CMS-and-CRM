<?php

namespace Woo_PA\Controllers;

use Woo_PA\Woo_PA;

use Woo_PA\Woo_PA_Order;
use Woo_PA\Payment_Gateway\Payment_Meta_Box_Helper;
use YeEasyAdminNotices\V1\AdminNotice;

defined( 'ABSPATH' ) || die;

/**
 * Controller for the payment meta box.
 */
class Payment_Meta_Box_Controller {


    private $gateway;

    private $gateway_helper;

  
    private $order;

    private $gateway_template_directories = [];

    private $template_directories = [];

    private $charges;

    private $json_data;

    private $k_oplate;


    public $BIT_KKT_TOKEN;
    public $BIT_BNK_TRM_TOKEN;

  
    public static function add_meta_box() {
        $title = apply_filters( 'woo_pa_payments_meta_box_title', 'Payments' );

        add_meta_box( 'woo-pa', $title, [ new static(), 'display' ] );
    }

       private function validation() {
        $validation = [];

        /*if ( $this->gateway_helper ) {
            if ( $this->payment_currency !== $this->order->get_currency() ) {
                $validation[] = [
                    'message' => "Transactions will be processed in $this->payment_currency.",
                    'type'    => 'info',
                    'valid'   => true,
                ];
            }

            $validation = array_merge(
                $validation,
                $this->validate_missing_gateway_settings(),
                $this->gateway_helper->validation()
            );
        } else {
            $validation[] = [
                'message' => sprintf(
                    'Please <a href="%s">select a payment gateway</a>. %s',
                    WOO_PA_SETTINGS_URL,
                    WOO_PA_CONFIG_HELP
                ),
                'type'    => 'info',
                'valid'   => false,
            ];
        }

        if ( $validation ) {
            $errors = array_values( array_filter(
                $validation,
                function ( $message ) {
                    return ! $message['valid'];
                }
            ) );

            if ( $errors ) {
                $validation = [ $errors[0] ];
            }

            foreach ( $validation as $message ) {
                $notice = AdminNotice::create();

                if ( $message['valid'] ) {
                    $notice->dismissible();
                }

                $notice
                    ->type( $message['type'] )
                    ->addClass( 'inline' )
                    ->html( wp_kses_post( $message['message'] ) )
                    ->outputNotice();
            }

            if ( $errors ) {
                return false;
            }
        }*/

        return true;
    }

    /**
     * Check for missing payment gateway settings.
     *
     * @return array[] Validation messages in the format specified {@see Payment_Meta_Box_Helper::validation() here}.
     */
    private function validate_missing_gateway_settings() 
    {
        $validation = [];

        /*$gateway      = $this->gateway;
        $settings_url = WOO_PA_SETTINGS_URL . '&section=' . $gateway::ID;

        foreach ( $this->get_missing_gateway_settings() as $setting ) {
            $validation[] = [
                'message' => "Please <a href='$settings_url'>set your {$setting['title']}</a>. " . WOO_PA_CONFIG_HELP,
                'type'    => 'info',
                'valid'   => false,
            ];
        }*/

        return $validation;
    }

    /**
     * Get missing payment gateway settings.
     *
     * @return array[] A list of missing settings in the WooCommerce format.
     */
    private function get_missing_gateway_settings() {
        $missing_settings = [];

        foreach ( $this->gateway->get_settings_section()->get_settings() as $setting ) {
            if ( ! empty( $setting['required'] ) && ! get_option( $setting['id'] ) ) {
                $missing_settings[] = $setting;
            }
        }

        return $missing_settings;
    }


    private function enqueue_assets() 
    {
        $suffix = SCRIPT_DEBUG ? '' : '.min';

		
        //wp_enqueue_style( 'woo-pa-style', WOO_PA_URL . '/assets/css/style.css', [], WOO_PA_VERSION );
		
		wp_enqueue_style( 'woo-pa-style', WOO_PA_URL . '/assets/css/shared.css', [], WOO_PA_VERSION );		

        if ( version_compare( $GLOBALS['wp_version'], '5.7-beta1', '<' ) ) {
            wp_enqueue_style( 'woo-pa-style-5-7', WOO_PA_URL . '/assets/css/wp-backward-compatibility/style-5-7.css', [], WOO_PA_VERSION );
        }

        if ( version_compare( $GLOBALS['wp_version'], '5.3-beta1', '<' ) ) {
            wp_enqueue_style( 'woo-pa-style-5-3', WOO_PA_URL . '/assets/css/wp-backward-compatibility/style-5-3.css', [], WOO_PA_VERSION );
        }

        //wp_enqueue_script( 'jquery-payment', plugins_url( "assets/js/jquery-payment/jquery.payment$suffix.js", WC_PLUGIN_FILE ), [], WC_VERSION, true );
		
		
		wp_enqueue_script('jquery-ui-dialog');
		
		wp_enqueue_script( 'woo-pa-shared', WOO_PA_URL . "/assets/js/shared.js",  [], WOO_PA_VERSION, true );
		
        //wp_enqueue_script( 'woo-pa-script', WOO_PA_URL . '/assets/js/script.js', [], WOO_PA_VERSION, true );


        do_action( 'woo_pa_enqueued_assets' );

        //$this->gateway_helper->enqueue_assets();

        
        $client_data =  [
			'AJAXURL'        => admin_url( 'admin-ajax.php' ), // это для ajax-ов
			'nonces'         => [ // это тоже надо для обратки
                'woo_pa_process_transaction' => wp_create_nonce( 'woo_pa_process_transaction_' . $this->order->get_id() ),
            ],			
            'BIT_KKT_TOKEN'      => $this->BIT_KKT_TOKEN,
            'BIT_BNK_TRM_TOKEN'      => $this->BIT_BNK_TRM_TOKEN,
            'URL'               => 'http://localhost:44735',
            'orderID'        => $this->order->get_id(),
            'editOrderURL'   => $this->order->get_edit_order_url(),
			'currencySymbol' => get_woocommerce_currency_symbol( $this->payment_currency ),
        ];

        wp_localize_script( 'woo-pa-shared', 'wooPA', $client_data );
    }

    /**
     * Initialize the template system.
     *
     * @return void
     */
    private function init_templates() 
	{
        $directories = array_merge(
            $this->gateway_template_directories,
            [ WOO_PA_PATH . '/templates' ],
            Woo_PA::is_pro() ? [ WOO_PA_CONFIG_HELP . '/templates' ] : []
        );

        /**
         * Filters the list of directories used to find templates.
         *
         * Use `array_unshift()` to add your custom template directory.
         * This will ensure that your templates override the default ones.
         *
         * Warning: The templates are not covered by any backward-compatibility guarantee.
         *          Test each release before updating your production site.
         *
         * @param string[] $directories The absolute directory paths, ordered from higher priority to lower priority.
         */
        $this->template_directories = apply_filters( 'woo_pa_payments_meta_box_template_directories', $directories );
    }

    /**
     * Output a template.
     *
     * @param  string $name The name of the template.
     * @return void
     */
    private function template( $name ) {
        foreach ( $this->template_directories as $directory ) {
            $path = "$directory/$name.php";

            if ( is_readable( $path ) ) {
                require $path;

                break;
            }
        }
    }

    public function get_k_oplate() 
    {
        return $this->k_oplate;
    }

    private function set_k_oplate( $sum ) 
    {
        $this->k_oplate = $sum;
    }

    public function get_json_data() 
    {
        return $this->json_data;
    }

    private function set_json_data( $json_data ) 
    {
        $this->json_data = $json_data;
    }
               

    public function display() 
    {

        $this->order                        = new Woo_PA_Order( wc_get_order() );
        $this->charges                      = $this->order->get_woo_pa_payments();


        $wc_order = wc_get_order( $_REQUEST['id'] );

        $items=[];
        
       foreach ($wc_order->get_items() as $item => $arr)
        {
            $itm=[];
            $product = $arr->get_product();

            $itm["productName_1030"] = $product->get_name();
            $get_type = $product->get_type();
            $itm["qty_1023"] = $arr->get_quantity();
            $itm["sum"] = $arr->get_subtotal();
            $get_taxes = $arr->get_taxes();
            $get_variation_id= $arr->get_variation_id();

            $itm["unit_2108"] = 0;
            $itm["paymentFormCode_1214"] = 4;
            $itm["tax_1199"] = 6;

            $items[] = $itm;
        }

        $data["purchases"] = $items; 
        $data["cashierName_1021"] = "Пупкин Иван Трофимович";
        $data["cashierInn_1203"]= "";
        $data["taxationType_1055"]= 5;
        $data["receiptType_1054"]= 1;
        //$data["sendToEmail_1008"]= 1;

        $this->set_json_data($data);

		$this->BIT_KKT_TOKEN = get_option( 'woo_pa_bit_kkt_token' , '');
		$this->BIT_BNK_TRM_TOKEN = get_option( 'woo_pa_bit_bnk_trm_token'  , '' );

        $this->set_k_oplate ( $wc_order->get_total() );

        $ddd= $this->get_k_oplate();


        if ( ! $this->validation() ) {
            return;
        }

        $this->enqueue_assets();

        $this->init_templates();

        $this->template( 'payments-meta-box' );
    }
	
	public function save_charge( $charge ) 
	{
        $charge['order']->add_woo_pa_payment( [
            'id'              => $charge['trans_id'],
            'last4'           => $charge['last_4'],
            'amount'          => $charge['amount'],
            'currency'        => $charge['currency'],
            'captured'        => $charge['capture'],
            'held_for_review' => $charge['held_for_review'],
        ] );

        $should_save_wc_payment = false;

        switch ( get_option( 'woo_pa_save_wc_payment_when', 'first_payment' ) ) {
            case 'first_payment':
                $should_save_wc_payment = ! $charge['order']->get_date_paid( 'edit' );
                break;
            case 'every_payment':
                $should_save_wc_payment = true;
                break;
        }

        if ( $should_save_wc_payment ) {
            $method_title = $this->payment_gateway->get_payment_method_title();

            $charge['order']->set_payment_method( $method_title );
            $charge['order']->set_payment_method_title( $method_title );
            $charge['order']->set_transaction_id( $charge['trans_id'] );
            $charge['order']->set_date_paid( time() );
        }

        $charge['order']->save();
    }
	public function do_success(  $charge ) 
	{
        //$this->add_charge_note( $charge );
        $this->save_charge( $charge );
		 $this->update_meta_data( 'woo-pa-' . WOO_PA_PAYMENT_PROCESSOR , json_encode( '{"asaa":"dfsdfds"}' ) );
		/* 
        $this->update_status( $charge );
        $this->reduce_stock( $charge );

        do_action( 'woo_mp_payment_complete', $charge['order']->get_core_order() );

        $message = $charge['capture'] ? 'Payment successfully processed.' : 'Payment successfully authorized.';

        if ( $charge['held_for_review'] ) {
            $message = 'Payment held for review.';
        }

        AdminNotice::create( 'message' )
            ->dismissible()
            ->success( wp_kses_post( $message ) )
            ->showOnNextPage();*/
    }	

}
