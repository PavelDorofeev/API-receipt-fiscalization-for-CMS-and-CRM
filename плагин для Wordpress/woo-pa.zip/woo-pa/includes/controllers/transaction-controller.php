<?php

namespace Woo_PA\Controllers;

use Woo_PA\Woo_PA;
//use Woo_PA\Payment_Gateways;
//use Woo_PA\Payment_Processor;
use Woo_PA\Detailed_Exception;
use Woo_MP\Woo_MP_Order;

defined( 'ABSPATH' ) || die;

/**
 * Transaction request controller.
 */
class Transaction_Controller {

    /**
     * Process a transaction.
     *
     * @return void
     */
    public function process_transaction() 
	{
        check_ajax_referer( 'woo_pa_process_transaction_' . ( isset( $_REQUEST['order_id'] ) ? $_REQUEST['order_id'] : 0 ) );

        if ( ! current_user_can( 'edit_shop_orders' ) ) {
            wp_die( 'Sorry, you are not allowed to process transactions for this order.', 403 );
        }

       /* if ( isset( $_REQUEST['gateway_id'] ) && $_REQUEST['gateway_id'] !== Payment_Gateways::get_active_id() ) {
            $this->respond(
                'error',
                'The active payment gateway has been switched.' .
                ' Please refresh the page and try again.'
            );
        }*/
        $rr = $_REQUEST['order_id'] ;

        $charge=[];
        $charge['order'] = new Woo_MP_Order( wc_get_order( $_REQUEST['order_id'] ) );
        $charge['trans_id'] = "234";
        $charge['id'] = "2345";
        $charge['amount'] = 230;
        $charge['held_for_review']  = "354354354354";

        


        try {
            //$data = $this->process( $_POST );
            $this->update_status( $charge );

            $this->respond( 'success', '', null, $data );
            
        } catch ( Detailed_Exception $e ) {
            $this->respond( 'error', $e->getMessage(), $e->getCode(), $e->get_data() );
        } catch ( \Throwable $e ) {
            $this->respond( 'error', 'An error has occured: ' . $e, $e->getCode() );
        } catch ( \Exception $e ) {
            $this->respond( 'error', 'An error has occured: ' . $e, $e->getCode() );
        }

        die;
    }

    private function update_status( $charge ) 
	{
        $update_order_status_when = get_option( 'woo_mp_update_order_status_when' );
        $update_order_status_to   = get_option( 'woo_mp_update_order_status_to', 'wc-completed' );

        $should_update_status = false;

        if ( $update_order_status_when === 'any_transaction' ) {
            $should_update_status = true;
        } elseif ( $update_order_status_when === 'total_amount_charged' ) {
            if ( $charge['order']->get_total_amount_unpaid() <= 0 ) {
                $should_update_status = true;
            }
        }

        if ( $should_update_status ) {

            // Patch https://github.com/woocommerce/woocommerce/issues/20057.
            if ( version_compare( WC_VERSION, '3.4.0', '<' ) ) {
                if ( ! $charge['order']->get_date_created( 'edit' ) ) {
                    $charge['order']->set_date_created( time() );
                }
            }

            $charge['order']->update_status( $update_order_status_to );
        }
    }

    private function process( $params ) {
        $processors = [
            'charge' => Payment_Processor::class,
        ];

        /*if ( Woo_PA::is_pro() ) {
            $processors += [
                'refund' => \Woo_PA_Pro\Refund_Processor::class,
            ];
        }*/

        /*if ( empty( $params['transaction_type'] ) ) {
            throw new Detailed_Exception( "The 'transaction_type' parameter is required." );
        }*/

        if ( empty( $processors[ $params['transaction_type'] ] ) ) {
            throw new Detailed_Exception( "Transaction type '$params[transaction_type]' was not found." );
        }

        return ( new $processors[ $params['transaction_type'] ]() )->process( $params );
    }


    private function respond( $status, $message = '', $code = null, $data = null ) {
        wp_send_json( [
            'status'  => $status,
            'message' => $message,
            'code'    => $code,
            'data'    => $data,
        ] );
    }

}
