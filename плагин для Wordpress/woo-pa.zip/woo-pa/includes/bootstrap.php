<?php

namespace Woo_PA;

use YeEasyAdminNotices\V1\AdminNotice;

defined( 'ABSPATH' ) || die;

require WOO_PA_PATH . '/includes/autoloader.php';

( new Autoloader( 'Woo_PA\\', WOO_PA_PATH . '/includes/' ) )->register();

if ( ! class_exists( AdminNotice::class ) ) {
    require WOO_PA_PATH . '/libraries/admin-notices-1.1/AdminNotice.php';
}

( new Woo_PA() )->init();
