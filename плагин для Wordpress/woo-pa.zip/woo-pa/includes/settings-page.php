<?php

namespace Woo_PA;

defined( 'ABSPATH' ) || die;

/**
 * Payment Acceptance settings.
 *
 * This class extends `WC_Settings_Page`. Therefore, care must be taken to
 * ensure that this class is only loaded when `WC_Settings_Page` is loaded.
 */
class Settings_Page extends \WC_Settings_Page {

    /**
     * The ID of this settings page.
     *
     * @var string
     */
    const ID = 'payment_acceptance';

    /**
     * A list of all payment gateways with gateway IDs as keys and instances of the main gateway objects as values.
     *
     * @var array
     */
    private $payment_gateways = [];

    /**
     * Gateway titles keyed by gateway ID.
     *
     * @var array
     */
    private $payment_gateway_titles = [];

    public function __construct() {
        $this->id    = self::ID;
        $this->label = __( 'Payment Acceptance', 'woo-pa' );

        $this->payment_gateways = Payment_Gateways::get_all();

        foreach ( $this->payment_gateways as $id => $gateway ) {
            $this->payment_gateway_titles[ $id ] = $gateway->get_title();
        }

        parent::__construct();
    }

    public function get_sections() {
        $sections = [ '' => __( 'General', 'woo-pa' ) ] + $this->payment_gateway_titles;

        return apply_filters( 'woocommerce_get_sections_' . $this->id, $sections );
    }

    public function get_settings() {
        global $current_section;

        $text_style = 'width: 400px;';

        $settings = [];

        if ( $current_section === '' ) {
            $settings = [
                [
                    'title' => __( 'Settings', 'woo-pa' ),
                    'type'  => 'title',
                    'desc'  => WOO_PA_CONFIG_HELP,
                ],
                [
                    'title'    => __( 'BIT_KKT_TOKEN', 'woo-pa' ),
                    'desc'     => __( 'BIT_KKT_TOKEN is a unigue hash od your kkt.', 'woo-pa' ),
                    'id'       => 'woo_pa_bit_kkt_token',
                    'type'     => 'text',
                    'default'  => '',
                    'desc_tip' => true,
                    'css'      => $text_style,
                ],
                [
                    'title'    => __( 'BIT_BNK_TRM_TOKEN', 'woo-pa' ),
                    'desc'     => __( 'BIT_BNK_TRM_TOKEN is a unigue hash of your bank terminal.', 'woo-pa' ),
                    'id'       => 'woo_pa_bit_bnk_trm_token',
                    'type'     => 'text',
                    'default'  => '',
                    'desc_tip' => true,
                    'css'      => $text_style,
                ],				
                [
                    'title'    => __( 'Изменять статус заказа', 'woo-pa' ),
                    'desc'     => __( 'Выберите если вам надо изменять статус заказа после оплаты', 'woo-pa' ),
                    'id'       => 'woo_pa_update_order_status_when',
                    'type'     => 'select',
                    'class'    => 'wc-enhanced-select',
                    'desc_tip' => true,
                    'options'  => [
                        ''                     => __( "Не изменять статус заказа", 'woo-pa' ),
                        'any_transaction'      => __( 'Если оплата принята успешно', 'woo-pa' ),
                    ],
                ],
                [
                    'title'    => __( 'Изменить статус заказа в', 'woo-pa' ),
                    'desc'     => __( 'Выберите значение, в которое изменять статус заказа.', 'woo-pa' ),
                    'id'       => 'woo_pa_update_order_status_to',
                    'type'     => 'select',
                    'class'    => 'wc-enhanced-select',
                    'desc_tip' => true,
                    'default'  => 'wc-completed',
                    'options'  => wc_get_order_statuses(),
                ],
                [
                    'title'    => __( 'Save WooCommerce Payment Record When', 'woo-pa' ),
                    'desc'     => __( 'Choose when you want an official (native) WooCommerce payment record to be saved to an order. Please note that WooCommerce only supports one official payment per order. This means that if you choose to save a record any time a payment or authorization is made, previous payment information will be overwritten. You will still be able to see past payments in the <em>Order notes</em> section.', 'woo-pa' ),
                    'id'       => 'woo_pa_save_wc_payment_when',
                    'type'     => 'select',
                    'class'    => 'wc-enhanced-select',
                    'desc_tip' => true,
                    'default'  => 'first_payment',
                    'options'  => [
                        'first_payment' => __( 'The first payment or authorization is made', 'woo-pa' ),
                        'every_payment' => __( 'Any payment or authorization is made (see help tip)', 'woo-pa' ),
                        'never'         => __( "Don't save WooCommerce payment records", 'woo-pa' ),
                    ],
                ],
                [
                    'title'    => __( 'Reduce Stock Levels When', 'woo-pa' ),
                    'desc'     => __( 'Choose when you want order item stock levels to be reduced. Stock levels will never be reduced more than once. Please note that this option only applies when stock management is enabled at both the global and product level.', 'woo-pa' ),
                    'id'       => 'woo_pa_reduce_stock_levels_when',
                    'type'     => 'select',
                    'class'    => 'wc-enhanced-select',
                    'desc_tip' => true,
                    'default'  => 'any_charge',
                    'options'  => [
                        'any_charge'           => __( 'A payment or authorization is made', 'woo-pa' ),
                        'total_amount_charged' => __( 'The total amount has been paid or authorized', 'woo-pa' ),
                        'never'                => __( "Don't reduce stock levels", 'woo-pa' ),
                    ],
                ],
                [
                    'type' => 'sectionend',
                ],
            ];
        } else {
            if ( isset( $this->payment_gateways[ $current_section ] ) ) {
                $settings = $this->payment_gateways[ $current_section ]->get_settings_section()->get_settings();
            }
        }

        return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings, $current_section );
    }

}
