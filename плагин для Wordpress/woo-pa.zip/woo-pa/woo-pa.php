<?php

/**
 * Plugin Name: WooCommerce Payment Acceptance
 * Description: Process payments from the WooCommerce Edit Order screen.
 * Version: 2.8.4
 * Author: BIT Ltd
 * Text Domain: woo-pa
 * WC requires at least: 3.3
 * WC tested up to: 9
 */

defined( 'ABSPATH' ) || die;

$woo_pa_should_load = ( is_admin() && ! is_network_admin() ) || ( defined( 'DOING_CRON' ) && DOING_CRON );

/**
 * Filters whether the plugin should load.
 *
 * You will need to bind your callback before this plugin loads.
 *
 * Warning: This plugin is intended to be used in the WP Admin. It may not
 *          function correctly outside of it. Loading the plugin outside of
 *          the WP Admin may also impact the security of your site. Test each
 *          release before updating your production site.
 *
 * @param bool $should_load Whether the plugin should load.
 */
$woo_pa_should_load = apply_filters( 'woo_pa_should_load', $woo_pa_should_load );

if ( ! $woo_pa_should_load ) {
    return;
}

define( 'WOO_PA_VERSION', '1.0.0' );
define( 'WOO_PA_PRO_COMPAT_VERSION', 9 );
define( 'WOO_PA_PATH', dirname( __FILE__ ) );
define( 'WOO_PA_URL', plugins_url( '', __FILE__ ) );
define( 'WOO_PA_BASENAME', basename( dirname( __FILE__ ) ) . '/' . basename( __FILE__ ) );

require WOO_PA_PATH . '/includes/woo-pa-requirement-checks.php';

if ( ! Woo_PA_Requirement_Checks::run() ) {
    return;
}

require WOO_PA_PATH . '/includes/bootstrap.php';
